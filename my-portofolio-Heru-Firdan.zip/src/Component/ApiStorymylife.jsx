const ApiStoryofmylife = [
  {
    judul: "Pendidikan",
    poin1: "SMK Negeri 1 Bukittinggi",
    poin2: "UIN SJECH M. DJAMIL DJAMBEK BUKITTINGGI",
    subpoin1: "Teknik Komputer dan Jaringan",
    subpoin2: "Pendidikan Teknik Informatika dan Komputer",
  },
  {
    judul: "Pengalaman",
    poin1: "SMK Negeri 4 Sijunjung",
    poin2: "ASA Charity Padang",
    subpoin1: "Operator Dapodik",
    subpoin2: "Relawan",
  },
];

export default ApiStoryofmylife;
